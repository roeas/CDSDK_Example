#pragma once

#include "Box.hpp"

namespace cd
{

using AABB = TBox<float>;

}