#pragma once

namespace cdtools
{

enum class ExportMode
{
	XmlBinary = 0,
	PureBinary,
};

}